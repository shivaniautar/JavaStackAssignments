
public class MapOfTheHashmatiqueTest{
    public static void main(String[] args){
    MapOfTheHashmatique info = new MapOfTheHashmatique();

    info.getSongData();
    }
}