public class BasicJavaTest{
    public static void main (String[] args){
        BasicJava basic=new BasicJava();
        // basic.printTo255();

        // basic.printOdd255();

        //basic.printSum255();

        // int[] x={1,3,5,7,9,13};
        // basic.printArray(x);

        // int [] testArr2={-3,-5,-7};
        // basic.printMax(testArr2);

        // int [] testArr3={2,10,3};
        // basic.printAvg(testArr3);

        //basic.arrOdd();

        // int [] testArr4={1, 3, 5, 7};
        // int num=3;
        // basic.greaterThan(testArr4,num);

        // int[] testArr5={1,5,10,-2};
        // basic.squareVals(testArr5);

        // int[] testArr6={1,5,10,-2};
        // basic.elimNeg(testArr6);

        // int [] testArr7={1,5,10,-2};
        // basic.maxMinAvg(testArr7);

        // int [] testArr8={1,5,10,7,-2};
        // basic.shiftArr(testArr8);
    }
}