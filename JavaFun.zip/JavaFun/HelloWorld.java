public class HelloWorld{
    public static void main(String[] args) {
        System.out.println("Hi, My name is Shivani Autar");
        System.out.println("I am 25 years old");
        System.out.println("My hometown is Hayward, CA");
    }
}