
public class ListOfExceptionsTest{
    public static void main(String[] args){
    ListOfExceptions info = new ListOfExceptions();

    info.exceptionsList();
    }
}